/*
Cleaning Data in SQL Queries
*/

SELECT *
FROM SQL_Data_Exploration_Project..Nashville_Housing

-------------------------------------------------------------------------------------------------------------------------------------
-- Standardize Date Format

SELECT SaleDate
FROM SQL_Data_Exploration_Project..Nashville_Housing

ALTER TABLE Nashville_Housing
ADD SalesDateConverted DATE;

UPDATE Nashville_Housing
SET SalesDateConverted = CONVERT(DATE,[SaleDate])

SELECT SalesDateConverted
FROM SQL_Data_Exploration_Project..Nashville_Housing

--------------------------------------------------------------------------------------------------------------------------------------
-- Populate Property Address Data

SELECT PropertyAddress
FROM SQL_Data_Exploration_Project..Nashville_Housing
WHERE PropertyAddress IS NULL

SELECT a.ParcelID, a.PropertyAddress, b.ParcelID, b.PropertyAddress
FROM SQL_Data_Exploration_Project..Nashville_Housing a
JOIN SQL_Data_Exploration_Project..Nashville_Housing b
	ON a.ParcelID = b.ParcelID
	AND a.UniqueID <> b.UniqueID
WHERE a.PropertyAddress IS NULL

UPDATE a
SET PropertyAddress = ISNULL(a.PropertyAddress, b.PropertyAddress)
FROM SQL_Data_Exploration_Project..Nashville_Housing a
JOIN SQL_Data_Exploration_Project..Nashville_Housing b
	ON a.ParcelID = b.ParcelID
	AND a.UniqueID <> b.UniqueID
WHERE a.PropertyAddress IS NULL

SELECT *
FROM SQL_Data_Exploration_Project..Nashville_Housing
WHERE PropertyAddress IS NULL

--------------------------------------------------------------------------------------------------------------------------------------
-- Breaking OUT Address into Indivisual Columns (Address, City, State)

SELECT PropertyAddress
FROM SQL_Data_Exploration_Project..Nashville_Housing

SELECT 
SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress) - 1) AS Address,
SUBSTRING(PropertyAddress, CHARINDEX(',',PropertyAddress) + 1, LEN(PropertyAddress)) AS City
FROM SQL_Data_Exploration_Project..Nashville_Housing

ALTER TABLE Nashville_Housing
ADD PropertyNewAddress NVARCHAR(255);

UPDATE Nashville_Housing
SET PropertySplitAddress = SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress) - 1)

ALTER TABLE Nashville_Housing
ADD PropertyCity NVARCHAR(255);

UPDATE Nashville_Housing
SET PropertyCity = SUBSTRING(PropertyAddress, CHARINDEX(',',PropertyAddress) + 1, LEN(PropertyAddress))

SELECT *
FROM SQL_Data_Exploration_Project..Nashville_Housing

--- Owner Address
SELECT OwnerAddress
FROM SQL_Data_Exploration_Project..Nashville_Housing

SELECT 
PARSENAME(REPLACE(OwnerAddress, ',', '.'), 1),
PARSENAME(REPLACE(OwnerAddress, ',', '.'), 2),
PARSENAME(REPLACE(OwnerAddress, ',', '.'), 3)
FROM SQL_Data_Exploration_Project..Nashville_Housing

ALTER TABLE Nashville_Housing
ADD OwnerSplitAddress NVARCHAR(255);

UPDATE Nashville_Housing
SET OwnerSplitAddress = PARSENAME(REPLACE(OwnerAddress, ',', '.'), 3)

ALTER TABLE Nashville_Housing
ADD OwnerCity NVARCHAR(255);

UPDATE Nashville_Housing
SET OwnerCity = PARSENAME(REPLACE(OwnerAddress, ',', '.'), 2)

ALTER TABLE Nashville_Housing
ADD OwnerState NVARCHAR(255);

UPDATE Nashville_Housing
SET OwnerState = PARSENAME(REPLACE(OwnerAddress, ',', '.'), 1)

SELECT *
FROM SQL_Data_Exploration_Project..Nashville_Housing

----------------------------------------------------------------------------------------------------------------------------------
-- Change Y & N to Yes and No

SELECT DISTINCT(SoldAsVacant), COUNT(SoldAsVacant)
FROM SQL_Data_Exploration_Project..Nashville_Housing
GROUP BY SoldAsVacant

--SELECT CONVERT(nvarchar(50),SoldAsVacant)
--FROM SQL_Data_Exploration_Project..Nashville_Housing

--UPDATE Nashville_Housing
--SET SoldAsVacant = CONVERT(nvarchar(50),SoldAsVacant)

SELECT SoldAsVacant,
CASE
	WHEN SoldAsVacant = 'N' THEN 'No'
	WHEN SoldAsVacant = 'Y' THEN 'Yes'
	ELSE SoldAsVacant
END
FROM SQL_Data_Exploration_Project..Nashville_Housing

UPDATE Nashville_Housing
SET SoldAsVacant = CASE
	WHEN SoldAsVacant = 'N' THEN 'No'
	WHEN SoldAsVacant = 'Y' THEN 'Yes'
	ELSE SoldAsVacant
END

-------------------------------------------------------------------------------------------------------------------------------------
-- Remove Duplicates

-- Find the Duplicates
WITH RowNumb
AS (
SELECT *, ROW_NUMBER() OVER (PARTITION BY ParcelID, PropertyAddress, SaleDate, SalePrice, LegalReference
				ORDER BY UniqueID ) AS row_num
FROM SQL_Data_Exploration_Project..Nashville_Housing
)
SELECT *
FROM RowNumb
WHERE row_num > 1
ORDER BY PropertyAddress;


-- Remove
WITH RowNumb
AS (
SELECT *, ROW_NUMBER() OVER (PARTITION BY ParcelID, PropertyAddress, SaleDate, SalePrice, LegalReference
				ORDER BY UniqueID ) AS row_num
FROM SQL_Data_Exploration_Project..Nashville_Housing
)
DELETE
FROM RowNumb
WHERE row_num > 1

--------------------------------------------------------------------------------------------------------------------------------
-- Delete UnUsed Column (** Not Advised to Perform on RAW Data, Better on TEMP or VIEW)

SELECT *
FROM SQL_Data_Exploration_Project..Nashville_Housing

ALTER TABLE SQL_Data_Exploration_Project..Nashville_Housing
DROP COLUMN TaxDistrict

ALTER TABLE SQL_Data_Exploration_Project..Nashville_Housing
DROP COLUMN SaleDate
